import { Component, OnInit } from '@angular/core';

import {Developer} from "../developer"
import { DeveloperService } from '../developer.service';

@Component({
  selector: 'app-bio',
  templateUrl: './bio.component.html',
  styleUrls: ['./bio.component.css']
})
export class BioComponent implements OnInit {
  devs: Developer[];
  // constructor() { 
  //   this.devs = [new Developer("Ramesh", "Selvarasu", "PHP", 2006),
  //   new Developer("Mohitha", "Ramesh", "PHP", 2012),
  //   new Developer("Prema", "Selvarasu", "React", 2013)]
  // }

  constructor(developerService:DeveloperService){
    this.devs = developerService.getAllDevelopers();
  }

  ngOnInit() {
  }

}
