import { Component } from '@angular/core';

export class Developer {
    firstName: string;
    lastName: string;
    favoriteDevLanguage: string;
    yearStarted: number;

    constructor(firstName: string, lastName: string, favoriteDevLanguage: string, yearStarted: number){
        this.firstName = firstName;
        this.lastName = lastName;
        this.favoriteDevLanguage = favoriteDevLanguage;
        this.yearStarted = yearStarted;
    }
}
