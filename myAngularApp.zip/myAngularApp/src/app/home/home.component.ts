import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor() { }
  
  title = 'hellowAngular';
  myColor: string = "yellow";

  changeColor():void{
    this.myColor = this.myColor=="Red" ? "Green" : "Red";
  } 

  ngOnInit() {
  }

}
