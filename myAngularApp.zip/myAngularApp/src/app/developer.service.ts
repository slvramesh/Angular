import { Injectable } from '@angular/core';
import {Developer} from "../app/developer"

@Injectable({
  providedIn: 'root'
})
export class DeveloperService {
  devs: Developer[];
  constructor() { 
    this.devs = [new Developer("Ramesh", "Selvarasu", "PHP", 2006),
    new Developer("Mohitha", "Ramesh", "PHP", 2012),
    new Developer("Prema", "Selvarasu", "React", 2013)]
  }
  
  getAllDevelopers():Developer[]{
    return this.devs;
  }
}
