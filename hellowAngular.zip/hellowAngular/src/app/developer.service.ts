import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import {catchError, map} from 'rxjs/operators';

import {Developer} from "../app/developer"

@Injectable(
//   {
//   providedIn: 'root'
// }

)
export class DeveloperService {
  devs: Developer[];

  private url: string = "http://54.202.108.54/Home/";
  constructor(private httpClient:HttpClient) { 
    // this.devs = [new Developer(1, "Ramesh", "Selvarasu", "PHP", 2006),
    // new Developer(2, "Mohitha", "Ramesh", "PHP", 2012),
    // new Developer(3, "Prema", "Selvarasu", "React", 2013)]


  }
  
  // getAllDevelopers():Developer[]{
  //   return this.devs;
  // }

  getAllDeveloper():Observable<Developer[]>{
    return this.httpClient.get<Developer[]>(this.url+"Developers").pipe(
      map(response=>{this.devs = response; return response;}),
      catchError(this.handleError<any>())
    )
  }

  // getDeveloperById(devId:number):Developer{
  //   return this.devs.find(dev => dev.id == devId);
  // }

  getDeveloperById(devId: number): Developer {
    return this.devs.find(dev => dev.id == devId);
  }

  addDeveloper(formData: FormData): boolean{
    this.httpClient.post(this.url+"AddDeveloper", formData)
    .subscribe(res=>{
      }, (err)=>{
        console.log(err);
      });
      return true;
  } 

  private handleError<T>( result?: T) {
    return (error: any): Observable<T> => {
      console.log('An Error occured' + error);
      return null;
    }
  }
  
}
